package FunctionLayer;

/**
 * The purpose of LoginSampleException is to...
 * @author kasper
 */
public class LegoException extends Exception {

    public LegoException(String msg) {
        super(msg);
    }
    

}
